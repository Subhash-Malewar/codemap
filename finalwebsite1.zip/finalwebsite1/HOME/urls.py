from django.contrib import admin
from django.urls import path, include
from HOME import views


urlpatterns = [

    path('',views.home,name='home'),
    path('signup',views.Signupevent,name='Signupevent'),
    path('login',views.Loginevent,name='Loginevent'),
    path('logout',views.Logoutevent,name='Logoutevent'),
]
